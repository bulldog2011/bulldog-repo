Nano
========

A super light xml and json binding framework targeting android platform.