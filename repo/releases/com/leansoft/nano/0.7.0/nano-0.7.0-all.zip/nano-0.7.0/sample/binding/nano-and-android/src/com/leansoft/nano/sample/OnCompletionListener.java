package com.leansoft.nano.sample;

public interface OnCompletionListener {
	
	public void onCompletion(Object result);

}
